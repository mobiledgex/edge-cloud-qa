package com.mobiledgex.newapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.UiAutomation;
import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.os.Looper;
//import androidx.test.platform.app.InstrumentationRegistry;

import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.Pair;
import android.app.Activity;

//import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.common.eventbus.Subscribe;
import com.mobiledgex.matchingengine.MatchingEngine;
import com.mobiledgex.matchingengine.edgeeventsconfig.ClientEventsConfig;
import com.mobiledgex.matchingengine.edgeeventsconfig.EdgeEventsConfig;
import com.mobiledgex.matchingengine.edgeeventsconfig.FindCloudletEvent;
import com.mobiledgex.matchingengine.edgeeventsconfig.FindCloudletEventTrigger;
import com.mobiledgex.matchingengine.performancemetrics.NetTest;
import com.mobiledgex.matchingengine.DmeDnsException;
import com.mobiledgex.mel.MelMessaging;
import com.mobiledgex.matchingengine.util.RequestPermissions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import distributed_match_engine.AppClient;

import static com.mobiledgex.matchingengine.util.RequestPermissions.REQUEST_MULTIPLE_PERMISSION;
import static com.mobiledgex.matchingengine.util.RequestPermissions.permissions;
import static distributed_match_engine.AppClient.FindCloudletReply.FindStatus.FIND_FOUND;

public class MainActivity extends AppCompatActivity {

    String TAG = "MainActivity";
    public static final long GRPC_TIMEOUT_MS = 25000;
    private Activity context;

    // QA
    public static String carrierName = "TDG";
    public static final String organizationName = "MobiledgeX";
    public static final String applicationName = "automation-sdk-porttest";
    public static final String appVersion = "1.0";
    public static String hostOverride = "eu-qa.dme.mobiledgex.net";
    public static String findCloudletCarrierOverride = "TDG"; // Allow "Any" if using "", but this likely breaks test cases.

    // Production
    //public static String carrierName = "TELUS";
    //public static final String organizationName = "MobiledgeX-Samples";
    //public static final String applicationName = "ComputerVision";
    //public static final String applicationName = "sdktest";
    //public static final String appVersion = "9.0";
    //public static final String appVersion = "2.2";
    //public static String hostOverride = "wifi.dme.mobiledgex.net";
    //public static String findCloudletCarrierOverride = "TELUS"; // Allow "Any" if using "", but this likely breaks test cases.

    public static int portOverride = 50051;
    public boolean useHostOverride = true;
    public boolean useWifiOnly = true; // This also disables network switching, since the android default is WiFi.

    public static final int REQUEST_MULTIPLE_PERMISSION = 1001;
    public static final String[] permissions = new String[] { // Special Enhanced security requests.
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE, // Get network state.
    };

    private LocationCallback mLocationCallback;
    private LocationResult mLocationResult;
    FusedLocationProviderClient fusedLocationClient;
    private LocationRequest mLocationRequest = new LocationRequest();

    private void startLocationUpdates() {
        try {
            if (fusedLocationClient == null) {
                fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            }
            mLocationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    if (locationResult == null) {
                        return;
                    }
                    String clientLocText = "";
                    mLocationResult = locationResult;
                    // Post into edgeEvents updater:
                    for (Location location : locationResult.getLocations()) {
                        // Update UI with client location data
                        clientLocText += "[" + location.toString() + "]";
                    }
                }
            };
            fusedLocationClient.requestLocationUpdates(
                    mLocationRequest,
                    mLocationCallback,
                    Looper.getMainLooper() /* Looper */);
        } catch (SecurityException se) {
            Log.e(TAG, "SecurityException message: " + se.getLocalizedMessage());
            se.printStackTrace();
            Log.i(TAG, "App should Request location permissions during onResume() or onCreate().");
        }
    }
    CompletableFuture<Void> someFuture;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        requestPermissions(this);
        startLocationUpdates();

        someFuture = CompletableFuture.runAsync(() -> {
            testDefaultConfigNoChanges();
            // Insert long running code here. Like get().
            });
    }

    public List<String> getNeededPermissions(AppCompatActivity activity) {
        List<String> permissionsNeeded = new ArrayList<>();
        for (String pStr : permissions) {
            int result = ContextCompat.checkSelfPermission(activity, pStr);
            if (result != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(pStr);
            }
        }
        return permissionsNeeded;
    }
    public void requestMultiplePermissions(AppCompatActivity activity) {
        // Check which ones missing
        List<String> permissionsNeeded = getNeededPermissions(activity);
        String[] permissionArray;
        if (!permissionsNeeded.isEmpty()) {
            permissionArray = permissionsNeeded.toArray(new String[permissionsNeeded.size()]);
        } else {
            permissionArray = permissions; // Nothing was granted. Ask for all.
        }
        ActivityCompat.requestPermissions(activity, permissionArray, REQUEST_MULTIPLE_PERMISSION);
    }
    /*!
     * Check and ask for permissions needed for MobiledgeX MatchingEngine SDK and EdgeEvents.
     */
    private void requestPermissions(AppCompatActivity appCompatActivity) {
        if (getNeededPermissions(appCompatActivity).size() > 0) {
            requestMultiplePermissions(appCompatActivity);
        }
    }


    public Location getTestLocation() {
        Location location = new Location("EngineCallTestLocation");
        location.setLatitude(33.00);
        location.setLongitude(96.54);
        //location.setLongitude(52.3759);
        //location.setLatitude(9.735603);
        return location;
    }

    public void registerClient(MatchingEngine me) {
        AppClient.RegisterClientReply registerReply;
        AppClient.RegisterClientRequest regRequest;

        try {
            // The app version will be null, but we can build from scratch for test
            List<Pair<String, Long>> ids = me.retrieveCellId(context);
            AppClient.RegisterClientRequest.Builder regRequestBuilder = AppClient.RegisterClientRequest.newBuilder()
                    .setOrgName(organizationName)
                    .setAppName(applicationName)
                    .setAppVers(appVersion);
            if (ids.size() > 0) {
                regRequestBuilder.setCellId(me.retrieveCellId(context).get(0).second.intValue());
            }
            regRequest = regRequestBuilder.build();
            if (useHostOverride) {
                registerReply = me.registerClient(regRequest, hostOverride, portOverride, GRPC_TIMEOUT_MS);
            } else {
                registerReply = me.registerClient(regRequest, GRPC_TIMEOUT_MS);
            }
            //assertEquals("Response SessionCookie should equal MatchingEngine SessionCookie",
            //        registerReply.getSessionCookie(), me.getSessionCookie());
        } catch (DmeDnsException dde) {
            Log.e(TAG, Log.getStackTraceString(dde));
        } catch (ExecutionException ee) {
            Log.e(TAG, Log.getStackTraceString(ee));
        } catch (InterruptedException ioe) {
            Log.e(TAG, Log.getStackTraceString(ioe));
        }
    }

    public void testDefaultConfigNoChanges() {
        Future<AppClient.FindCloudletReply> response1;
        AppClient.FindCloudletReply findCloudletReply1;
        MatchingEngine me = new MatchingEngine(context);
        me.setMatchingEngineLocationAllowed(true);
        me.setAllowSwitchIfNoSubscriberInfo(true);
        // This EdgeEventsConnection test requires an EdgeEvents enabled server.
        // me.setSSLEnabled(false);
        // me.setNetworkSwitchingEnabled(false);
        // attach an EdgeEventBus to receive the server response, if any (inline class):
        final List<AppClient.ServerEdgeEvent> responses = new ArrayList<>();
        final List<FindCloudletEvent> latencyNewCloudletResponses = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);
        class EventReceiver2 {
            @Subscribe
            void HandleEdgeEvent(AppClient.ServerEdgeEvent edgeEvent) {
                switch (edgeEvent.getEventType()) {
                    case EVENT_LATENCY_PROCESSED:
                        Log.i(TAG, "Received a latency processed response: " + edgeEvent);
                        responses.add(edgeEvent);
                        latch.countDown();
                        break;
                }
            }
            @Subscribe
            void HandleFindCloudlet(FindCloudletEvent fce) {
                latencyNewCloudletResponses.add(fce);
            }
        }
        EventReceiver2 er = new EventReceiver2();
        me.getEdgeEventsBus().register(er);
        try {
            Location location = getTestLocation(); // Test needs this configurable in a sensible way.
            registerClient(me);
            //enableMockLocation(context,true);

            // Cannot use the older API if overriding.
            AppClient.FindCloudletRequest findCloudletRequest = me.createDefaultFindCloudletRequest(context, location)
                    .setCarrierName(findCloudletCarrierOverride)
                    .build();
            EdgeEventsConfig edgeEventsConfig = me.createDefaultEdgeEventsConfig();
            if (useHostOverride) {
                response1 = me.findCloudletFuture(findCloudletRequest, hostOverride, portOverride, GRPC_TIMEOUT_MS,
                        MatchingEngine.FindCloudletMode.PROXIMITY);
                // start on response1
                me.startEdgeEventsFuture(edgeEventsConfig);
            } else {
                response1 = me.findCloudletFuture(findCloudletRequest, GRPC_TIMEOUT_MS, MatchingEngine.FindCloudletMode.PROXIMITY);
                // start on response1
                me.startEdgeEvents(edgeEventsConfig);
            }
            findCloudletReply1 = response1.get();
            latch.await(GRPC_TIMEOUT_MS * 1, TimeUnit.MILLISECONDS);
            // This is actually unbounded, as the default is infinity latency Processed resposnes, should you wait long enough for that many to start arriving.
            long expectedNum = 1; // edgeEventsConfig.latencyUpdateConfig.maxNumberOfUpdates;
            Log.i(TAG, "EdgeEvent :  " + responses.size());
            // FIXME: For this test, the location is NON-MOCKED, a MOCK location provider is required to get sensible results here, but the location timer task is going.
            //assertEquals("Must get new FindCloudlet responses back from server.", 0, latencyNewCloudletResponses.size());
            for (AppClient.ServerEdgeEvent s : responses) {
                Log.i(TAG, "Edge Event  :  " + s.getEventType());
            }
        } catch (DmeDnsException dde) {
            Log.e(TAG, Log.getStackTraceString(dde));
        } catch (ExecutionException ee) {
            Log.e(TAG, Log.getStackTraceString(ee));
        } catch (InterruptedException ie) {
            Log.e(TAG, Log.getStackTraceString(ie));
        } finally {
            if (me != null) {
                Log.i(TAG, "Closing matching engine...");
                me.close();
                Log.i(TAG, "MatchingEngine closed for test.");
            }
        }
    }

}